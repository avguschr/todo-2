export const data = localStorage.getItem("notes") || [];
